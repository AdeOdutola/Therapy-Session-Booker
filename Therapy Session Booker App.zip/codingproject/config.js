const config = {
    mongodb: 'mongodb+srv://Strapz:NDyjk8TZCNB2rmFo@cluster0.impra.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
}

module.exports = config